﻿using EShop.Domain.DomainModels;
using EShop.Domain.DomainModels.Identity;
using System;
using System.Collections.Generic;


namespace TicketHomework.Models.Domain
{
	public class Order : BaseEntity
	{

		public string UserId { get; set; }

		public ApplicationUser User { get; set; }

		public virtual ICollection<ProductInOrder> Products { get; set; }
	}
}
