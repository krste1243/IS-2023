﻿using System;
using TicketHomework.Models.Domain;

namespace EShop.Domain.DomainModels
{
	public class ProductInOrder : BaseEntity
	{
		public Guid ProductId { get; set; }

		public Ticket SelectedProduct { get; set; }

		public Guid OrderId { get; set; }

		public Order UserOrder { get; set; }
		public int Quantity { get; set; }
	}
}
