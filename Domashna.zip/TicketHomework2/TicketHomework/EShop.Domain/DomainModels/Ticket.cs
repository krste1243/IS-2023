﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EShop.Domain.DomainModels
{
	public class Ticket : BaseEntity
	{
        [Required]
        public string TicketName { get; set; }

        [Required]
        public string TicketImage { get; set; }
        
        [Required]
        public double ticketPrice { get; set; }

        [Required]
        public string Genre { get; set; }

        [Required]
        public int Duration { get; set; }

        public int Rating { get; set; }

		[Required]
		public DateTime TimeMovie { get; set; }

        public virtual ICollection<TicketInShoppingCart> ticketInShoppingCart { get; set; }

        public virtual ICollection<ProductInOrder> Orders { get; set; }

        public Ticket() { }

    }
}
