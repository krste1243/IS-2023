﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EShop.Domain.DomainModels
{
	public class BaseEntity
	{
		public Guid Id { get; set; }
	}
}
