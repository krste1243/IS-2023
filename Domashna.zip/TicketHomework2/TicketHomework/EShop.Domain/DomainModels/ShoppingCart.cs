﻿using EShop.Domain.DomainModels.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


namespace EShop.Domain.DomainModels
{
	public class ShoppingCart : BaseEntity
	{
		public string OwnerId { get; set; }	

		public virtual ApplicationUser owner { get; set; }

		public virtual ICollection<TicketInShoppingCart> ticketInShoppingCart { get; set; }
	
		public ShoppingCart() { }
	}
}
