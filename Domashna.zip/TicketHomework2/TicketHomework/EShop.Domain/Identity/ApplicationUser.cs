﻿using Microsoft.AspNetCore.Identity;
using TicketHomework.Models.Domain;

namespace EShop.Domain.DomainModels.Identity

{
	public class ApplicationUser : IdentityUser
	{
		public string FirstName { get; set; }

		public string LastName { get; set; }

		public string Address { get; set; }

		public virtual ShoppingCart UserCard { get; set; }
	}
}
