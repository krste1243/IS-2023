﻿using System.Collections.Generic;
using TicketHomework.Models.Domain;

namespace EShop.Domain.DomainModels.DTO
{
	public class ShoppingCartDto
	{
		public List<TicketInShoppingCart> TicketInShoppingCart { get; set; }

		public double TotalPrice { get; set; }
	}
}
