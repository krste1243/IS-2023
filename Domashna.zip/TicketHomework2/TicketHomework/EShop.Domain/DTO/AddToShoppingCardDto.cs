﻿using System;
using TicketHomework.Models.Domain;

namespace EShop.Domain.DomainModels.DTO
{
	public class AddToShoppingCardDto
	{
		public Ticket SelectedProduct { get; set; }

		public Guid ProductId { get; set; }

		public int Quantity { get; set; }
	}
}
