﻿using EShop.Domain.DomainModels;
using EShop.Domain.DomainModels.DTO;
using EShop.Repository.Interface;
using EShop.Services.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TicketHomework.Models.Domain;

namespace EShop.Services.Implementation
{
    public class ShoppingCartService : IShoppingCartService
    {
        private readonly IRepository<ShoppingCart> _shoppingCartRepository;
        private readonly IUserRepository _userRepository;

        public ShoppingCartService(IRepository<ShoppingCart> shoppingCartRepository, IUserRepository userRepository)
        {
            _shoppingCartRepository = shoppingCartRepository;
            _userRepository = userRepository;

        }

        public ShoppingCartDto getShoppingCartInfo(string userId)
        {
            if (!string.IsNullOrEmpty(userId))
            {
                var loggedInUser = this._userRepository.Get(userId);

                var userCard = loggedInUser.UserCard;

                var allProducts = userCard.ticketInShoppingCart.ToList();

                var allProductPrices = allProducts.Select(z => new
                {
                    ProductPrice = z.Ticket.ticketPrice,
                    Quantity = z.Quantity
                }).ToList();

                double totalPrice = 0.0;

                foreach (var item in allProductPrices)
                {
                    totalPrice += item.Quantity * item.ProductPrice;
                }

                var result = new ShoppingCartDto
                {
                    TicketInShoppingCart = allProducts,
                    TotalPrice = totalPrice
                };

                return result;
            }
            return new ShoppingCartDto();
        }

        public bool deleteProductFromSoppingCart(string userId, Guid productId)
        {
            if (!string.IsNullOrEmpty(userId) && productId != null)
            {
                var loggedInUser = this._userRepository.Get(userId);

                var userShoppingCart = loggedInUser.UserCard;

                var itemToDelete = userShoppingCart.ticketInShoppingCart.Where(z => z.TicketId.Equals(productId)).FirstOrDefault();

                userShoppingCart.ticketInShoppingCart.Remove(itemToDelete);

                this._shoppingCartRepository.Update(userShoppingCart);

                return true;
            }
            return false;
        }

        public bool order(string userId)
        {
            throw new NotImplementedException();    
            //    if (!string.IsNullOrEmpty(userId))
            //    {
            //        var loggedInUser = this._userRepository.Get(userId);
            //        var userCard = loggedInUser.UserCard;

            //        EmailMessage mail = new EmailMessage();
            //        mail.MailTo = loggedInUser.Email;
            //        mail.Subject = "Sucessfuly created order!";
            //        mail.Status = false;


            //        Order order = new Order
            //        {
            //            Id = Guid.NewGuid(),
            //            User = loggedInUser,
            //            UserId = userId
            //        };

            //        this._orderRepository.Insert(order);

            //        List<ProductInOrder> productInOrders = new List<ProductInOrder>();

            //        var result = userCard.ProductInShoppingCarts.Select(z => new ProductInOrder
            //        {
            //            Id = Guid.NewGuid(),
            //            ProductId = z.CurrnetProduct.Id,
            //            Product = z.CurrnetProduct,
            //            OrderId = order.Id,
            //            Order = order,
            //            Quantity = z.Quantity
            //        }).ToList();

            //        StringBuilder sb = new StringBuilder();

            //        var totalPrice = 0.0;

            //        sb.AppendLine("Your order is completed. The order conatins: ");

            //        for (int i = 1; i <= result.Count(); i++)
            //        {
            //            var currentItem = result[i - 1];
            //            totalPrice += currentItem.Quantity * currentItem.Product.ProductPrice;
            //            sb.AppendLine(i.ToString() + ". " + currentItem.Product.ProductName + " with quantity of: " + currentItem.Quantity + " and price of: $" + currentItem.Product.ProductPrice);
            //        }

            //        sb.AppendLine("Total price for your order: " + totalPrice.ToString());

            //        mail.Content = sb.ToString();


            //        productInOrders.AddRange(result);

            //        foreach (var item in productInOrders)
            //        {
            //            this._productInOrderRepository.Insert(item);
            //        }

            //        loggedInUser.UserCard.ticketInShoppingCart.Clear();

            //        this._userRepository.Update(loggedInUser);
            //        this._mailRepository.Insert(mail);

            //        return true;
            //    }

            //    return false;
            //}
        }

    }
}
